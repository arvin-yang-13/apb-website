import { UserRound } from 'lucide-react'
import SectionHeading from './ui/SectionHeading'
import { TEACHER_SLOT_COUNT } from '../data/teachers'
import { useLanguage } from '../i18n/LanguageContext'

export default function Teachers() {
  const { t } = useLanguage()
  const slots = Array.from({ length: TEACHER_SLOT_COUNT }, (_, i) => i)

  return (
    <section id="teachers" className="py-20 sm:py-28 bg-ice scroll-mt-20 sm:scroll-mt-24">
      <div className="container-page">
        <SectionHeading
          eyebrow={t.teachers.eyebrow}
          title={t.teachers.title}
          description={t.teachers.description}
          align="center"
        />

        <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {slots.map((slot) => (
            <div
              key={slot}
              className="card-surface rounded-2xl overflow-hidden border border-dashed border-navy-900/15"
            >
              <div className="aspect-[4/3] bg-navy-50 flex items-center justify-center">
                <UserRound size={40} className="text-navy-300" strokeWidth={1.3} aria-hidden="true" />
              </div>
              <div className="p-5 text-center">
                <p className="font-display text-base font-semibold text-navy-900">
                  {t.teachers.cardTitle}
                </p>
                <p className="text-sm text-gold-600 font-medium mt-1">{t.teachers.cardStatus}</p>
                <p className="text-xs text-navy-500 mt-2 leading-relaxed">
                  {t.teachers.cardNote}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
