import SectionHeading from './ui/SectionHeading'
import { features } from '../data/features'
import { useLanguage } from '../i18n/LanguageContext'

export default function WhyChoose() {
  const { t } = useLanguage()

  return (
    <section id="why-apb" className="py-20 sm:py-28 bg-white scroll-mt-20 sm:scroll-mt-24">
      <div className="container-page">
        <SectionHeading
          eyebrow={t.whyChoose.eyebrow}
          title={t.whyChoose.title}
          description={t.whyChoose.description}
        />

        <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {features.map(({ id, icon: Icon }) => {
            const copy = t.whyChoose.features[id as keyof typeof t.whyChoose.features]
            return (
              <div
                key={id}
                className="group rounded-2xl p-7 border border-navy-900/8 bg-white transition-all duration-300 hover:border-gold-300/60 hover:shadow-soft hover:-translate-y-1"
              >
                <div className="h-11 w-11 rounded-full bg-navy-900 flex items-center justify-center text-gold-300 transition-colors duration-300 group-hover:bg-gold-400 group-hover:text-navy-900">
                  <Icon size={19} strokeWidth={1.8} aria-hidden="true" />
                </div>
                <h3 className="font-display text-lg font-semibold text-navy-900 mt-5">
                  {copy.title}
                </h3>
                <p className="mt-2 text-sm text-navy-700/75 leading-relaxed">
                  {copy.description}
                </p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
