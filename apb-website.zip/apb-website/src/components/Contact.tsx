import { MapPin, Phone, ArrowRight } from 'lucide-react'
import BookingForm from './BookingForm'
import { useLanguage } from '../i18n/LanguageContext'

const MAPS_URL =
  'https://www.google.com/maps/search/?api=1&query=111%2F29-30+Malada+Maz%2C+San+Phak+Wan%2C+Hang+Dong%2C+Chiang+Mai+50230%2C+Thailand'

export default function Contact() {
  const { t } = useLanguage()

  return (
    <section id="contact" className="relative scroll-mt-20 sm:scroll-mt-24">
      {/* CTA band */}
      <div id="booking" className="bg-navy-900 pt-20 sm:pt-24 pb-16 relative overflow-hidden scroll-mt-24">
        <div
          className="absolute inset-0 bg-grid-lines bg-[size:48px_48px] opacity-[0.05]"
          aria-hidden="true"
        />
        <div className="container-page relative text-center">
          <span className="eyebrow text-gold-300">{t.contact.eyebrow}</span>
          <h2 className="font-display text-3xl sm:text-5xl font-semibold text-white mt-4 leading-tight">
            {t.contact.title}
          </h2>
          <p className="mt-4 text-white/65 max-w-lg mx-auto">
            {t.contact.subtitle}
          </p>
          <div className="mt-8 flex flex-col sm:flex-row flex-wrap gap-3.5 justify-center">
            <a href="#booking-form" className="btn btn-gold text-base px-7 py-3.5">
              {t.contact.ctaPrimary}
              <ArrowRight size={17} aria-hidden="true" />
            </a>
            <a
              href="tel:+66612729266"
              className="btn text-base px-7 py-3.5 border border-white/20 text-white hover:bg-white/10"
            >
              <Phone size={16} aria-hidden="true" />
              {t.contact.ctaCall}
            </a>
            <a
              href={MAPS_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="btn text-base px-7 py-3.5 border border-white/20 text-white hover:bg-white/10"
            >
              <MapPin size={16} aria-hidden="true" />
              {t.contact.ctaDirections}
            </a>
          </div>
        </div>
      </div>

      {/* Info + form */}
      <div className="bg-ice py-20 sm:py-24">
        <div className="container-page grid lg:grid-cols-[0.8fr_1.2fr] gap-12">
          <div>
            <h3 className="font-display text-2xl font-semibold text-navy-900">
              {t.contact.visitTitle}
            </h3>
            <div className="mt-7 space-y-5">
              <div className="flex items-start gap-3.5">
                <div className="h-10 w-10 rounded-full bg-white border border-navy-900/8 flex items-center justify-center text-navy-700 shrink-0">
                  <MapPin size={18} aria-hidden="true" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-navy-900">{t.contact.locationLabel}</p>
                  <p className="text-sm text-navy-700/80 mt-0.5 leading-relaxed">
                    111/29-30 Malada Maz, San Phak Wan,
                    <br />
                    Hang Dong, Chiang Mai 50230, Thailand
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3.5">
                <div className="h-10 w-10 rounded-full bg-white border border-navy-900/8 flex items-center justify-center text-navy-700 shrink-0">
                  <Phone size={18} aria-hidden="true" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-navy-900">{t.contact.phoneLabel}</p>
                  <a href="tel:+66612729266" className="text-sm text-navy-700/80 mt-0.5 hover:text-navy-900">
                    +66 61 272 9266
                  </a>
                </div>
              </div>
            </div>

            {/* Map link — opens the real APB location in Google Maps.
                No fake embedded iframe; this avoids implying a live map
                integration that isn't actually connected. */}
            <a
              href={MAPS_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-8 group flex items-center gap-4 rounded-2xl border border-navy-900/8 bg-white p-5 transition-colors hover:border-gold-300/60"
            >
              <div className="h-12 w-12 rounded-xl bg-navy-800 flex items-center justify-center text-gold-300 shrink-0">
                <MapPin size={20} strokeWidth={1.8} aria-hidden="true" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-semibold text-navy-900">{t.contact.directionsTitle}</p>
                <p className="text-xs text-navy-500 mt-0.5">{t.contact.directionsSubtitle}</p>
              </div>
              <ArrowRight
                size={17}
                className="ml-auto shrink-0 text-navy-400 transition-transform group-hover:translate-x-1 group-hover:text-gold-600"
                aria-hidden="true"
              />
            </a>
          </div>

          <div id="booking-form" className="scroll-mt-24">
            <h3 className="font-display text-2xl font-semibold text-navy-900 mb-6">
              {t.contact.formTitle}
            </h3>
            <BookingForm />
          </div>
        </div>
      </div>
    </section>
  )
}
