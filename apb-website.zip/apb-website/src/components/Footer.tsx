import { useLanguage } from '../i18n/LanguageContext'

export default function Footer() {
  const { t } = useLanguage()

  return (
    <footer className="bg-navy-950 text-white/60 py-10">
      <div className="container-page flex flex-col sm:flex-row items-center justify-between gap-5">
        <div className="flex items-center gap-2.5">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/10 text-white font-display font-semibold text-xs">
            A+
          </span>
          <span className="font-display font-medium text-white text-sm">
            {t.footer.tagline}
          </span>
        </div>
        <p className="text-xs text-center">
          &copy; {new Date().getFullYear()} A Plus Beyond (APB). {t.footer.rights}
        </p>
        <p className="text-xs">{t.footer.location}</p>
      </div>
    </footer>
  )
}
