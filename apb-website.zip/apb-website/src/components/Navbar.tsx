import { useEffect, useState } from 'react'
import { Menu, X, Languages } from 'lucide-react'
import { useLanguage } from '../i18n/LanguageContext'

export default function Navbar() {
  const { t, language, toggleLanguage } = useLanguage()
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  const navLinks = [
    { label: t.nav.home, href: '#home' },
    { label: t.nav.about, href: '#about' },
    { label: t.nav.programs, href: '#programs' },
    { label: t.nav.whyApb, href: '#why-apb' },
    { label: t.nav.faq, href: '#faq' },
    { label: t.nav.contact, href: '#contact' },
  ]

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    document.body.style.overflow = menuOpen ? 'hidden' : ''
    return () => {
      document.body.style.overflow = ''
    }
  }, [menuOpen])

  useEffect(() => {
    if (!menuOpen) return
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMenuOpen(false)
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [menuOpen])

  const handleLinkClick = () => setMenuOpen(false)

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-white/90 backdrop-blur-lg border-b border-navy-900/8 shadow-[0_1px_0_rgba(15,42,74,0.06)]'
          : 'bg-transparent border-b border-transparent'
      }`}
    >
      <nav className="container-page flex items-center justify-between h-[68px] sm:h-[72px]">
        <a href="#home" className="flex items-center gap-2.5 shrink-0 min-w-0" aria-label="APB home">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-navy-800 text-white font-display font-semibold text-sm shrink-0">
            A+
          </span>
          <span className="font-display font-semibold text-base sm:text-lg text-navy-900 tracking-tight truncate">
            A Plus Beyond
          </span>
        </a>

        <div className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm font-medium text-navy-800/80 hover:text-navy-900 transition-colors"
            >
              {link.label}
            </a>
          ))}
        </div>

        <div className="hidden lg:flex items-center gap-3">
          <button
            type="button"
            onClick={toggleLanguage}
            aria-label={t.nav.languageToggleLabel}
            className="flex items-center gap-1.5 rounded-full border border-navy-900/10 px-3.5 py-2 text-sm font-medium text-navy-800 hover:border-gold-300/60 hover:text-navy-900 transition-colors"
          >
            <Languages size={15} aria-hidden="true" />
            {t.nav.languageToggleShort}
          </button>
          <a href="#booking" className="btn btn-gold">
            {t.nav.bookTrial}
          </a>
        </div>

        <div className="flex items-center gap-2 lg:hidden">
          <button
            type="button"
            onClick={toggleLanguage}
            aria-label={t.nav.languageToggleLabel}
            className="flex items-center justify-center h-11 min-w-11 px-2.5 rounded-full border border-navy-900/10 text-sm font-medium text-navy-800 active:bg-navy-900/5 transition-colors"
          >
            {t.nav.languageToggleShort}
          </button>
          <button
            type="button"
            className="flex items-center justify-center h-11 w-11 -mr-1.5 rounded-full border border-navy-900/10 text-navy-900 active:bg-navy-900/5 transition-colors"
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={menuOpen}
            aria-controls="mobile-menu"
            onClick={() => setMenuOpen((v) => !v)}
          >
            {menuOpen ? <X size={20} aria-hidden="true" /> : <Menu size={20} aria-hidden="true" />}
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      <div
        id="mobile-menu"
        key={language}
        className={`lg:hidden fixed inset-x-0 top-[68px] sm:top-[72px] bottom-0 bg-white transition-transform duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] ${
          menuOpen ? 'translate-x-0' : 'translate-x-full pointer-events-none'
        }`}
        aria-hidden={!menuOpen}
      >
        <div className="flex flex-col h-full px-6 py-8 overflow-y-auto">
          <div className="flex flex-col gap-1">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={handleLinkClick}
                className="text-lg font-medium text-navy-900 py-3.5 border-b border-navy-900/6 active:text-gold-600 transition-colors"
              >
                {link.label}
              </a>
            ))}
          </div>
          <a
            href="#booking"
            onClick={handleLinkClick}
            className="btn btn-gold mt-8 w-full"
          >
            {t.nav.bookTrial}
          </a>
        </div>
      </div>
    </header>
  )
}
