import { useState } from 'react'
import { Plus } from 'lucide-react'
import SectionHeading from './ui/SectionHeading'
import { useLanguage } from '../i18n/LanguageContext'

export default function FAQ() {
  const { t } = useLanguage()
  const [openIndex, setOpenIndex] = useState<number | null>(0)

  return (
    <section id="faq" className="py-20 sm:py-28 bg-white scroll-mt-20 sm:scroll-mt-24">
      <div className="container-page">
        <div className="grid lg:grid-cols-[0.8fr_1.2fr] gap-12">
          <SectionHeading
            eyebrow={t.faq.eyebrow}
            title={t.faq.title}
            description={t.faq.description}
          />

          <div className="divide-y divide-navy-900/8 border-t border-b border-navy-900/8">
            {t.faq.items.map((item, index) => {
              const isOpen = openIndex === index
              return (
                <div key={item.question}>
                  <button
                    type="button"
                    className="w-full flex items-center justify-between gap-4 py-5 text-left"
                    aria-expanded={isOpen}
                    onClick={() => setOpenIndex(isOpen ? null : index)}
                  >
                    <span className="font-medium text-navy-900">{item.question}</span>
                    <Plus
                      size={18}
                      className={`shrink-0 text-gold-500 transition-transform duration-300 ${
                        isOpen ? 'rotate-45' : ''
                      }`}
                      aria-hidden="true"
                    />
                  </button>
                  <div
                    className={`grid transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] ${
                      isOpen ? 'grid-rows-[1fr] opacity-100 pb-5' : 'grid-rows-[0fr] opacity-0'
                    }`}
                  >
                    <div className="overflow-hidden">
                      <p className="text-navy-700/75 leading-relaxed pr-8">{item.answer}</p>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}
