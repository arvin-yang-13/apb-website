import { CheckCircle2 } from 'lucide-react'
import SectionHeading from './ui/SectionHeading'
import { useLanguage } from '../i18n/LanguageContext'

export default function About() {
  const { t } = useLanguage()

  return (
    <section id="about" className="py-20 sm:py-28 bg-white scroll-mt-20 sm:scroll-mt-24">
      <div className="container-page">
        <div className="grid lg:grid-cols-[0.85fr_1.15fr] gap-12 lg:gap-16 items-start">
          <SectionHeading
            eyebrow={t.about.eyebrow}
            title={t.about.title}
            description={t.about.description}
          />

          <div>
            <ul className="grid sm:grid-cols-2 gap-x-8 gap-y-5">
              {t.about.points.map((point) => (
                <li key={point} className="flex items-start gap-3">
                  <CheckCircle2 size={20} className="text-gold-500 shrink-0 mt-0.5" strokeWidth={2} aria-hidden="true" />
                  <span className="text-navy-800/85 leading-relaxed">{point}</span>
                </li>
              ))}
            </ul>

            <div className="mt-10 ledger-rule" />

            <p className="mt-8 text-navy-700/75 leading-relaxed max-w-2xl">
              {t.about.paragraph}
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
