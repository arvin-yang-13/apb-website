import { BookOpenCheck, Sparkles, ListChecks, Target, LineChart } from 'lucide-react'
import SectionHeading from './ui/SectionHeading'
import { useLanguage } from '../i18n/LanguageContext'

const BENEFIT_META = [
  { key: 'understanding', icon: BookOpenCheck },
  { key: 'confidence', icon: Sparkles },
  { key: 'habits', icon: ListChecks },
  { key: 'goals', icon: Target },
  { key: 'tracking', icon: LineChart },
] as const

export default function Results() {
  const { t } = useLanguage()

  return (
    <section id="results" className="py-20 sm:py-28 bg-ice scroll-mt-20 sm:scroll-mt-24">
      <div className="container-page">
        <SectionHeading
          eyebrow={t.results.eyebrow}
          title={t.results.title}
          description={t.results.description}
          align="center"
        />

        <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {BENEFIT_META.map(({ key, icon: Icon }) => {
            const copy = t.results.benefits[key]
            return (
              <div
                key={key}
                className="card-surface rounded-2xl p-7 transition-all duration-300 hover:shadow-soft hover:-translate-y-1"
              >
                <div className="h-11 w-11 rounded-xl bg-navy-800 flex items-center justify-center text-gold-300">
                  <Icon size={19} strokeWidth={1.8} aria-hidden="true" />
                </div>
                <h3 className="font-display text-lg font-semibold text-navy-900 mt-5">
                  {copy.title}
                </h3>
                <p className="mt-2 text-sm text-navy-700/75 leading-relaxed">
                  {copy.description}
                </p>
              </div>
            )
          })}
        </div>

        <p className="mt-8 text-center text-xs text-navy-500 font-mono">
          {t.results.footnote}
        </p>
      </div>
    </section>
  )
}
