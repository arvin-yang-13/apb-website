import SectionHeading from './ui/SectionHeading'
import { journeyStepIds } from '../data/journey'
import { useLanguage } from '../i18n/LanguageContext'

export default function StudentJourney() {
  const { t } = useLanguage()

  return (
    <section className="py-20 sm:py-28 bg-navy-900 relative overflow-hidden">
      <div
        className="absolute inset-0 bg-grid-lines bg-[size:48px_48px] opacity-[0.06] [mask-image:radial-gradient(ellipse_70%_60%_at_50%_40%,black,transparent)]"
        aria-hidden="true"
      />
      <div className="container-page relative">
        <div className="[&_.eyebrow]:text-gold-300 [&_h2]:text-white [&_p]:text-white/65">
          <SectionHeading
            eyebrow={t.journey.eyebrow}
            title={t.journey.title}
            description={t.journey.description}
            align="center"
          />
        </div>

        <div className="mt-16 grid sm:grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-0 relative">
          <div
            className="hidden lg:block absolute top-6 left-[12.5%] right-[12.5%] h-px bg-white/15"
            aria-hidden="true"
          />
          {journeyStepIds.map((stepId, i) => {
            const step = t.journey.steps[stepId]
            return (
              <div key={stepId} className="relative lg:px-6 lg:text-center">
                <span className="font-mono text-gold-300/80 text-sm block mb-3">
                  {String(i + 1).padStart(2, '0')}
                </span>
                <h3 className="font-display text-xl font-semibold text-white">
                  {step.title}
                </h3>
                <p className="mt-2 text-sm text-white/60 leading-relaxed lg:max-w-[15rem] lg:mx-auto">
                  {step.description}
                </p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
