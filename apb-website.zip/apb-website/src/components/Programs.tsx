import SectionHeading from './ui/SectionHeading'
import ProgramCard from './ui/ProgramCard'
import { programCategories } from '../data/programs'
import { useLanguage } from '../i18n/LanguageContext'

export default function Programs() {
  const { t } = useLanguage()

  return (
    <section id="programs" className="py-20 sm:py-28 bg-ice scroll-mt-20 sm:scroll-mt-24">
      <div className="container-page">
        <SectionHeading
          eyebrow={t.programs.eyebrow}
          title={t.programs.title}
          description={t.programs.description}
          align="center"
        />

        <div className="mt-16 space-y-16">
          {programCategories.map((category) => {
            const categoryCopy =
              t.programs.categories[category.id as keyof typeof t.programs.categories]
            return (
              <div key={category.id}>
                <div className="flex items-baseline justify-between gap-4 mb-6 flex-wrap">
                  <h3 className="font-display text-xl sm:text-2xl font-semibold text-navy-900">
                    {categoryCopy.title}
                  </h3>
                  <p className="text-sm text-navy-600/70">{categoryCopy.subtitle}</p>
                </div>
                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
                  {category.programs.map((program) => {
                    const programCopy = t.programs.items[program.id as keyof typeof t.programs.items]
                    return (
                      <ProgramCard
                        key={program.id}
                        icon={program.icon}
                        name={programCopy.name}
                        description={programCopy.description}
                        learnMoreLabel={t.programs.learnMore}
                      />
                    )
                  })}
                </div>
              </div>
            )
          })}
        </div>

        <p className="mt-12 text-center text-xs text-navy-500 font-mono">
          {t.programs.footnote}
        </p>
      </div>
    </section>
  )
}
