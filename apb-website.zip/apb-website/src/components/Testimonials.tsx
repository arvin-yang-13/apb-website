import { MessagesSquare } from 'lucide-react'
import SectionHeading from './ui/SectionHeading'
import { useLanguage } from '../i18n/LanguageContext'

export default function Testimonials() {
  const { t } = useLanguage()

  return (
    <section className="py-20 sm:py-28 bg-white">
      <div className="container-page">
        <SectionHeading eyebrow={t.testimonials.eyebrow} title={t.testimonials.title} align="center" />

        <div className="mt-14 max-w-xl mx-auto text-center">
          <div className="card-surface rounded-2xl p-10 sm:p-14">
            <div className="h-14 w-14 rounded-full bg-navy-50 border border-navy-900/8 mx-auto flex items-center justify-center text-navy-700">
              <MessagesSquare size={24} strokeWidth={1.7} aria-hidden="true" />
            </div>
            <h3 className="font-display text-2xl font-semibold text-navy-900 mt-6">
              {t.testimonials.comingSoonTitle}
            </h3>
            <p className="mt-3 text-navy-700/75 leading-relaxed">
              {t.testimonials.comingSoonBody}
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
