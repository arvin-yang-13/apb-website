import { ArrowUpRight } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

interface ProgramCardProps {
  icon: LucideIcon
  name: string
  description: string
  learnMoreLabel: string
}

export default function ProgramCard({ icon: Icon, name, description, learnMoreLabel }: ProgramCardProps) {
  return (
    <div className="group card-surface rounded-2xl p-6 flex flex-col h-full transition-all duration-300 hover:shadow-soft hover:-translate-y-1">
      <div className="h-12 w-12 rounded-xl bg-navy-50 flex items-center justify-center text-navy-700 group-hover:bg-navy-800 group-hover:text-white transition-colors duration-300">
        <Icon size={22} strokeWidth={1.8} aria-hidden="true" />
      </div>
      <h3 className="font-display text-lg font-semibold text-navy-900 mt-5">
        {name}
      </h3>
      <p className="mt-2 text-sm text-navy-700/75 leading-relaxed grow">
        {description}
      </p>
      <a
        href="#booking"
        className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-navy-800 hover:text-gold-600 transition-colors"
      >
        {learnMoreLabel}
        <ArrowUpRight size={15} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" aria-hidden="true" />
      </a>
    </div>
  )
}
