interface SectionHeadingProps {
  eyebrow: string
  title: string
  description?: string
  align?: 'left' | 'center'
}

export default function SectionHeading({
  eyebrow,
  title,
  description,
  align = 'left',
}: SectionHeadingProps) {
  const isCenter = align === 'center'
  return (
    <div className={isCenter ? 'text-center mx-auto max-w-2xl' : 'text-left max-w-2xl'}>
      <div
        className={`flex items-center gap-3 mb-4 ${isCenter ? 'justify-center' : 'justify-start'}`}
      >
        <span className="eyebrow">{eyebrow}</span>
        <span className="ledger-ticks" aria-hidden="true">
          <span className="h-1.5"></span>
          <span className="h-2.5"></span>
          <span className="h-1"></span>
          <span className="h-3"></span>
        </span>
      </div>
      <h2 className="font-display text-3xl sm:text-4xl md:text-[2.75rem] font-semibold text-navy-900 leading-[1.1]">
        {title}
      </h2>
      {description && (
        <p className="mt-4 text-base sm:text-lg text-navy-700/80 leading-relaxed">
          {description}
        </p>
      )}
    </div>
  )
}
