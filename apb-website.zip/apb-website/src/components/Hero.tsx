import { ArrowRight, Globe2, Sparkles, UsersRound, MapPin, ClipboardList, Compass, BookOpenCheck, TrendingUp } from 'lucide-react'
import { useLanguage } from '../i18n/LanguageContext'

const JOURNEY_STAGE_META = [
  { key: 'assessment', icon: ClipboardList },
  { key: 'plan', icon: Compass },
  { key: 'learn', icon: BookOpenCheck },
  { key: 'progress', icon: TrendingUp },
] as const

export default function Hero() {
  const { t } = useLanguage()

  const trustIndicators = [
    { label: t.hero.trust.curriculum, icon: Globe2 },
    { label: t.hero.trust.teachers, icon: UsersRound },
    { label: t.hero.trust.personalized, icon: Sparkles },
    { label: t.hero.trust.location, icon: MapPin },
  ]

  return (
    <section id="home" className="relative overflow-hidden pt-[104px] pb-16 sm:pt-[140px] sm:pb-28 scroll-mt-20 sm:scroll-mt-24">
      {/* ambient background — kept subtle and static, no glass overuse */}
      <div className="absolute inset-0 -z-10 bg-ice" aria-hidden="true">
        <div className="absolute inset-0 bg-grid-lines bg-[size:56px_56px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,black,transparent)]" />
        <div className="absolute -top-32 -right-40 h-[380px] w-[380px] rounded-full bg-navy-200/30 blur-3xl" />
      </div>

      <div className="container-page">
        <div className="grid lg:grid-cols-[1.05fr_0.95fr] gap-12 lg:gap-10 items-center">
          {/* Left: copy */}
          <div className="animate-fade-up">
            <div className="inline-flex items-center gap-2 rounded-full border border-navy-900/10 bg-white px-4 py-1.5 mb-6 sm:mb-7">
              <span className="ledger-ticks" aria-hidden="true">
                <span className="h-1"></span>
                <span className="h-2"></span>
                <span className="h-1.5"></span>
              </span>
              <span className="eyebrow">{t.hero.badge}</span>
            </div>

            <h1 className="font-display font-semibold text-navy-950 leading-[1.05] text-[2.4rem] sm:text-6xl md:text-[4.2rem]">
              {t.hero.headlineLine1}
              <br />
              {t.hero.headlineEmphasis && (
                <span className="italic text-navy-700">{t.hero.headlineEmphasis}</span>
              )}
              {t.hero.headlineRest}
            </h1>

            <p className="mt-5 sm:mt-6 text-lg sm:text-xl text-navy-800/75 max-w-xl leading-relaxed">
              {t.hero.subtitle}
            </p>

            <div className="mt-8 sm:mt-9 flex flex-col sm:flex-row gap-3.5">
              <a href="#booking" className="btn btn-primary text-base px-7 py-3.5">
                {t.hero.ctaPrimary}
                <ArrowRight size={17} aria-hidden="true" />
              </a>
              <a href="#programs" className="btn btn-ghost text-base px-7 py-3.5">
                {t.hero.ctaSecondary}
              </a>
            </div>

            <div className="mt-10 sm:mt-12 grid grid-cols-2 sm:flex sm:flex-wrap gap-x-8 gap-y-4">
              {trustIndicators.map(({ label, icon: Icon }) => (
                <div key={label} className="flex items-center gap-2 text-sm text-navy-800/70 font-medium">
                  <Icon size={16} className="text-gold-500" strokeWidth={2.25} aria-hidden="true" />
                  {label}
                </div>
              ))}
            </div>
          </div>

          {/* Right: signature visual — "APB Learning Journey" */}
          <div className="relative animate-fade-up [animation-delay:120ms]">
            <div className="relative mx-auto max-w-md">
              <div
                className="card-surface rounded-[1.75rem] p-7 sm:p-8"
                role="img"
                aria-label={t.hero.journey.title}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="eyebrow">{t.hero.journey.eyebrow}</p>
                    <p className="font-display text-xl font-semibold text-navy-900 mt-1">
                      {t.hero.journey.title}
                    </p>
                  </div>
                  <div className="h-11 w-11 rounded-xl bg-navy-800 flex items-center justify-center text-white font-display text-sm shrink-0">
                    A+
                  </div>
                </div>

                <ol className="mt-8 space-y-0">
                  {JOURNEY_STAGE_META.map((stage, i) => {
                    const Icon = stage.icon
                    const isLast = i === JOURNEY_STAGE_META.length - 1
                    const label =
                      stage.key === 'assessment'
                        ? t.hero.journey.stages.assessment
                        : stage.key === 'plan'
                          ? t.hero.journey.stages.plan
                          : stage.key === 'learn'
                            ? t.hero.journey.stages.learn
                            : t.hero.journey.stages.progress
                    return (
                      <li key={stage.key} className="relative flex gap-4 pb-8 last:pb-0">
                        {!isLast && (
                          <span
                            className="absolute left-[19px] top-10 bottom-0 w-px bg-navy-900/10"
                            aria-hidden="true"
                          />
                        )}
                        <span className="relative shrink-0 h-10 w-10 rounded-full bg-navy-50 border border-navy-900/8 flex items-center justify-center text-navy-700">
                          <Icon size={17} strokeWidth={1.8} aria-hidden="true" />
                        </span>
                        <div className="pt-1.5">
                          <span className="font-mono text-[0.7rem] text-gold-600 tracking-wide">
                            {String(i + 1).padStart(2, '0')}
                          </span>
                          <p className="font-display text-base font-semibold text-navy-900 leading-tight mt-0.5">
                            {label}
                          </p>
                        </div>
                      </li>
                    )
                  })}
                </ol>

                <div className="ledger-rule mt-2 mb-5" />

                <div className="flex items-center justify-between">
                  <p className="text-xs text-navy-500">{t.hero.journey.footnote}</p>
                  <div className="ledger-ticks" aria-hidden="true">
                    <span className="h-1.5"></span>
                    <span className="h-3"></span>
                    <span className="h-1"></span>
                    <span className="h-2"></span>
                    <span className="h-2.5"></span>
                  </div>
                </div>
              </div>

              <div className="absolute -bottom-6 -left-6 hidden sm:flex card-surface rounded-2xl px-5 py-4 items-center gap-3">
                <div className="h-9 w-9 rounded-full bg-gold-100 flex items-center justify-center text-gold-600 shrink-0">
                  <Sparkles size={17} aria-hidden="true" />
                </div>
                <div>
                  <p className="text-xs text-navy-500">{t.hero.journey.badgeLabel}</p>
                  <p className="text-sm font-semibold text-navy-900">{t.hero.journey.badgeValue}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
