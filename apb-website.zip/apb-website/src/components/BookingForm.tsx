import { useState } from 'react'
import type { ChangeEvent, FormEvent, ReactNode } from 'react'
import { CheckCircle2, Loader2 } from 'lucide-react'
import { useLanguage } from '../i18n/LanguageContext'
import type { Translations } from '../i18n/translations'

interface FormState {
  parentName: string
  studentName: string
  ageOrYear: string
  school: string
  subject: string
  program: string
  preferredDate: string
  preferredTime: string
  phone: string
  email: string
  message: string
}

const INITIAL_STATE: FormState = {
  parentName: '',
  studentName: '',
  ageOrYear: '',
  school: '',
  subject: '',
  program: '',
  preferredDate: '',
  preferredTime: '',
  phone: '',
  email: '',
  message: '',
}

const PROGRAM_OPTION_IDS = [
  'english',
  'mathematics',
  'science',
  'igcse',
  'aLevel',
  'ib',
  'sat',
  'ielts',
  'toefl',
  'internationalSchoolPrep',
  'academicTutoring',
] as const

type Errors = Partial<Record<keyof FormState, string>>

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

function validate(values: FormState, errorCopy: Translations['booking']['errors']): Errors {
  const errors: Errors = {}

  if (!values.parentName.trim()) errors.parentName = errorCopy.parentName
  if (!values.studentName.trim()) errors.studentName = errorCopy.studentName
  if (!values.ageOrYear.trim()) errors.ageOrYear = errorCopy.ageOrYear
  if (!values.program.trim()) errors.program = errorCopy.program

  if (!values.phone.trim()) {
    errors.phone = errorCopy.phone
  }

  if (!values.email.trim()) {
    errors.email = errorCopy.emailRequired
  } else if (!EMAIL_REGEX.test(values.email.trim())) {
    errors.email = errorCopy.emailInvalid
  }

  return errors
}

export default function BookingForm() {
  const { t } = useLanguage()
  const [values, setValues] = useState<FormState>(INITIAL_STATE)
  const [errors, setErrors] = useState<Errors>({})
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success'>('idle')

  const handleChange = (
    field: keyof FormState,
  ) => (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setValues((prev) => ({ ...prev, [field]: e.target.value }))
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }))
    }
  }

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault()
    const validationErrors = validate(values, t.booking.errors)
    setErrors(validationErrors)

    if (Object.keys(validationErrors).length > 0) return

    setStatus('submitting')

    // ------------------------------------------------------------------
    // FRONTEND-ONLY DEMO: no data is sent anywhere yet.
    // To go live, replace the block below with a real submission, e.g.:
    //
    //   const response = await fetch('https://your-api.example.com/bookings', {
    //     method: 'POST',
    //     headers: { 'Content-Type': 'application/json' },
    //     body: JSON.stringify(values),
    //   })
    //   if (!response.ok) { setStatus('idle'); return /* show an error state */ }
    //
    // Common options: a serverless function, a form service (e.g. Formspree,
    // Getform), or a direct integration with APB's CRM/inbox.
    // ------------------------------------------------------------------
    window.setTimeout(() => {
      setStatus('success')
    }, 900)
  }

  const handleReset = () => {
    setValues(INITIAL_STATE)
    setErrors({})
    setStatus('idle')
  }

  if (status === 'success') {
    const displayName = values.parentName.split(' ')[0] || t.booking.successBodyFallbackName
    const displayStudent = values.studentName || t.booking.successBodyFallbackStudent
    const successBody = t.booking.successBody
      .replace('{name}', displayName)
      .replace('{student}', displayStudent)

    return (
      <div className="card-surface rounded-2xl p-8 sm:p-10 text-center">
        <div className="h-14 w-14 rounded-full bg-navy-800 mx-auto flex items-center justify-center text-gold-300">
          <CheckCircle2 size={28} strokeWidth={1.8} aria-hidden="true" />
        </div>
        <h3 className="font-display text-2xl font-semibold text-navy-900 mt-6">
          {t.booking.successTitle}
        </h3>
        <p className="mt-3 text-navy-700/75 leading-relaxed max-w-sm mx-auto">
          {successBody}
        </p>
        <button type="button" onClick={handleReset} className="btn btn-ghost mt-7">
          {t.booking.resetButton}
        </button>
      </div>
    )
  }

  return (
    <form noValidate onSubmit={handleSubmit} className="card-surface rounded-2xl p-6 sm:p-9">
      <div className="flex items-start gap-2.5 rounded-xl bg-gold-50 border border-gold-200/70 px-4 py-3 mb-7 text-xs text-navy-700">
        <span className="font-mono text-gold-600 shrink-0">{t.booking.demoBannerTag}</span>
        <span>{t.booking.demoBannerText}</span>
      </div>
      <div className="grid sm:grid-cols-2 gap-5">
        <Field
          label={t.booking.fields.parentName}
          required
          error={errors.parentName}
          input={
            <input
              type="text"
              value={values.parentName}
              onChange={handleChange('parentName')}
              className={inputClass(!!errors.parentName)}
              placeholder={t.booking.placeholders.parentName}
            />
          }
        />
        <Field
          label={t.booking.fields.studentName}
          required
          error={errors.studentName}
          input={
            <input
              type="text"
              value={values.studentName}
              onChange={handleChange('studentName')}
              className={inputClass(!!errors.studentName)}
              placeholder={t.booking.placeholders.studentName}
            />
          }
        />
        <Field
          label={t.booking.fields.ageOrYear}
          required
          error={errors.ageOrYear}
          input={
            <input
              type="text"
              value={values.ageOrYear}
              onChange={handleChange('ageOrYear')}
              className={inputClass(!!errors.ageOrYear)}
              placeholder={t.booking.placeholders.ageOrYear}
            />
          }
        />
        <Field
          label={t.booking.fields.school}
          input={
            <input
              type="text"
              value={values.school}
              onChange={handleChange('school')}
              className={inputClass(false)}
              placeholder={t.booking.placeholders.school}
            />
          }
        />
        <Field
          label={t.booking.fields.subject}
          input={
            <input
              type="text"
              value={values.subject}
              onChange={handleChange('subject')}
              className={inputClass(false)}
              placeholder={t.booking.placeholders.subject}
            />
          }
        />
        <Field
          label={t.booking.fields.program}
          required
          error={errors.program}
          input={
            <select
              value={values.program}
              onChange={handleChange('program')}
              className={inputClass(!!errors.program)}
            >
              <option value="">{t.booking.placeholders.programSelect}</option>
              {PROGRAM_OPTION_IDS.map((id) => (
                <option key={id} value={id}>
                  {t.booking.programOptions[id]}
                </option>
              ))}
            </select>
          }
        />
        <Field
          label={t.booking.fields.preferredDate}
          input={
            <input
              type="date"
              value={values.preferredDate}
              onChange={handleChange('preferredDate')}
              className={inputClass(false)}
            />
          }
        />
        <Field
          label={t.booking.fields.preferredTime}
          input={
            <input
              type="time"
              value={values.preferredTime}
              onChange={handleChange('preferredTime')}
              className={inputClass(false)}
            />
          }
        />
        <Field
          label={t.booking.fields.phone}
          required
          error={errors.phone}
          input={
            <input
              type="tel"
              value={values.phone}
              onChange={handleChange('phone')}
              className={inputClass(!!errors.phone)}
              placeholder={t.booking.placeholders.phone}
            />
          }
        />
        <Field
          label={t.booking.fields.email}
          required
          error={errors.email}
          input={
            <input
              type="email"
              value={values.email}
              onChange={handleChange('email')}
              className={inputClass(!!errors.email)}
              placeholder={t.booking.placeholders.email}
            />
          }
        />
      </div>

      <div className="mt-5">
        <Field
          label={t.booking.fields.message}
          input={
            <textarea
              value={values.message}
              onChange={handleChange('message')}
              rows={4}
              className={inputClass(false)}
              placeholder={t.booking.placeholders.message}
            />
          }
        />
      </div>

      <button
        type="submit"
        disabled={status === 'submitting'}
        className="btn btn-primary w-full sm:w-auto mt-7 disabled:opacity-70"
      >
        {status === 'submitting' && <Loader2 size={17} className="animate-spin" aria-hidden="true" />}
        {status === 'submitting' ? t.booking.submitting : t.booking.submit}
      </button>
    </form>
  )
}

function inputClass(hasError: boolean) {
  return `w-full rounded-xl border px-4 py-3 text-sm text-navy-900 placeholder:text-navy-400 bg-white focus:outline-none focus:ring-2 transition-colors ${
    hasError
      ? 'border-red-300 focus:ring-red-200'
      : 'border-navy-900/12 focus:ring-gold-200 focus:border-gold-400'
  }`
}

function Field({
  label,
  input,
  required,
  error,
}: {
  label: string
  input: ReactNode
  required?: boolean
  error?: string
}) {
  return (
    <label className="block">
      <span className="text-sm font-medium text-navy-800">
        {label}
        {required && <span className="text-gold-600"> *</span>}
      </span>
      <div className="mt-1.5">{input}</div>
      {error && <span className="mt-1.5 block text-xs text-red-600">{error}</span>}
    </label>
  )
}
