import Navbar from './components/Navbar'
import Hero from './components/Hero'
import About from './components/About'
import Programs from './components/Programs'
import WhyChoose from './components/WhyChoose'
import StudentJourney from './components/StudentJourney'
import Results from './components/Results'
import Testimonials from './components/Testimonials'
import Teachers from './components/Teachers'
import FAQ from './components/FAQ'
import Contact from './components/Contact'
import Footer from './components/Footer'

function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Programs />
        <WhyChoose />
        <StudentJourney />
        <Results />
        <Testimonials />
        <Teachers />
        <FAQ />
        <Contact />
      </main>
      <Footer />
    </div>
  )
}

export default App
