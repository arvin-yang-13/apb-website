import { Compass, Globe2, Users, UsersRound, LineChart, UserCheck } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

export interface FeatureMeta {
  id: string
  icon: LucideIcon
}

// Text content lives in src/i18n/translations.ts under
// whyChoose.features.<id>. This file only defines ids + icons + order.
export const features: FeatureMeta[] = [
  { id: 'personalized', icon: Compass },
  { id: 'curriculumExpertise', icon: Globe2 },
  { id: 'educators', icon: Users },
  { id: 'smallClasses', icon: UsersRound },
  { id: 'progressTracking', icon: LineChart },
  { id: 'studentCentered', icon: UserCheck },
]
