import {
  Calculator,
  FlaskConical,
  BookOpenText,
  GraduationCap,
  Award,
  Globe2,
  Languages,
  PenTool,
  NotebookPen,
  School,
  Target,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

export interface ProgramMeta {
  id: string
  icon: LucideIcon
}

export interface ProgramCategoryMeta {
  id: string
  programs: ProgramMeta[]
}

// Text content (name, description, category title/subtitle) lives in
// src/i18n/translations.ts under programs.categories.<id> and
// programs.items.<id> so both languages stay in sync. This file only
// defines structure + icons.
export const programCategories: ProgramCategoryMeta[] = [
  {
    id: 'academic',
    programs: [
      { id: 'english', icon: Languages },
      { id: 'mathematics', icon: Calculator },
      { id: 'science', icon: FlaskConical },
      { id: 'academicTutoring', icon: NotebookPen },
    ],
  },
  {
    id: 'internationalCurriculum',
    programs: [
      { id: 'igcse', icon: Award },
      { id: 'aLevel', icon: GraduationCap },
      { id: 'ib', icon: Globe2 },
      { id: 'internationalSchoolPrep', icon: School },
    ],
  },
  {
    id: 'testPreparation',
    programs: [
      { id: 'ielts', icon: BookOpenText },
      { id: 'toefl', icon: PenTool },
      { id: 'sat', icon: Target },
    ],
  },
]
