// Text content lives in src/i18n/translations.ts under journey.steps.<id>.
// This file only defines the display order of steps.
export const journeyStepIds = ['assessment', 'plan', 'learn', 'achieve'] as const
export type JourneyStepId = (typeof journeyStepIds)[number]
