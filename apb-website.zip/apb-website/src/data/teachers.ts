// NOTE: Real APB teacher information (names, subjects, qualifications, and
// photos) has not been provided yet. Rather than invent placeholder names or
// credentials, this file only defines how many "coming soon" slots to show.
// Replace TEACHER_SLOT_COUNT and update src/components/Teachers.tsx once
// real teacher profiles are available.
export const TEACHER_SLOT_COUNT = 4
