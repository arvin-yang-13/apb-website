// Central translation dictionary for the APB website.
// `en` is the source of truth for shape; `zh` is typed against it so the
// two languages can never drift out of structural sync.

const en = {
  meta: {
    htmlLang: 'en',
  },
  nav: {
    home: 'Home',
    about: 'About',
    programs: 'Programs',
    whyApb: 'Why APB',
    faq: 'FAQ',
    contact: 'Contact',
    bookTrial: 'Book a Trial Class',
    languageToggleLabel: 'Switch to Chinese',
    languageToggleShort: '中文',
  },
  hero: {
    badge: 'Chiang Mai \u00b7 International Education',
    headlineLine1: 'Learn Beyond.',
    headlineEmphasis: 'Achieve',
    headlineRest: ' Beyond.',
    subtitle: 'Premium academic support for international school students in Chiang Mai.',
    ctaPrimary: 'Book a Trial Class',
    ctaSecondary: 'Explore Programs',
    trust: {
      curriculum: 'International Curriculum',
      teachers: 'Dedicated Teachers',
      personalized: 'Personalized Learning',
      location: 'Chiang Mai Based',
    },
    journey: {
      eyebrow: 'APB Learning Journey',
      title: 'How a student progresses',
      stages: {
        assessment: 'Assessment',
        plan: 'Personalized Plan',
        learn: 'Learn & Practice',
        progress: 'Progress',
      },
      footnote: 'Every student follows this same path',
      badgeLabel: 'Learning plan',
      badgeValue: 'Personalized',
    },
  },
  about: {
    eyebrow: 'About APB',
    title: 'A tutoring center built for international education.',
    description:
      'A Plus Beyond exists for one reason: to help students studying international curricula understand their subjects deeply, not just pass their exams.',
    points: [
      'Personalized teaching built around each student\u2019s pace and goals',
      'Academic support for students following international curricula',
      'Small-group and individual learning formats',
      'Subject-focused, one-on-one attention',
      'A student-centered approach to every lesson',
      'A clear focus on helping students reach their academic goals',
    ],
    paragraph:
      'Based in Hang Dong, Chiang Mai, APB offers academic support for students following international curricula \u2014 including IGCSE, A-Level, and IB coursework, IELTS, TOEFL, and SAT preparation, and core subject tutoring in English, Mathematics, and Science. Support can be tailored to the student\u2019s school, subject, and learning goals.',
  },
  programs: {
    eyebrow: 'Programs',
    title: 'Support for every stage of international study.',
    description:
      'From core subjects to specialist curriculum and test preparation, each program is tailored to the student\u2019s school and goals.',
    footnote: 'Academic support available depending on student needs, subject, and scheduling.',
    learnMore: 'Learn More',
    categories: {
      academic: {
        title: 'Academic Support',
        subtitle: 'Core subject support, built around each student\u2019s pace.',
      },
      internationalCurriculum: {
        title: 'International Curriculum',
        subtitle: 'Academic support for students following international school programs.',
      },
      testPreparation: {
        title: 'Test Preparation',
        subtitle: 'Structured practice for major English-language and admissions tests.',
      },
    },
    items: {
      english: {
        name: 'English',
        description:
          'Reading comprehension, essay writing, and language fluency, tailored to the student\u2019s school and level.',
      },
      mathematics: {
        name: 'Mathematics',
        description:
          'From foundational skills to more advanced topics, with clear, step-by-step problem solving.',
      },
      science: {
        name: 'Science',
        description:
          'Support across biology, chemistry, and physics, connecting classroom theory to practical understanding.',
      },
      academicTutoring: {
        name: 'Academic Tutoring',
        description:
          'General subject support and homework guidance for students who need consistent, personal attention.',
      },
      igcse: {
        name: 'IGCSE',
        description:
          'Academic support for students following the IGCSE curriculum, tailored to their subjects and school.',
      },
      aLevel: {
        name: 'A-Level',
        description:
          'Subject-by-subject support for A-Level students, tailored to their coursework and goals.',
      },
      ib: {
        name: 'IB',
        description:
          'Academic support for students following the IB program, tailored to the student\u2019s subjects and goals.',
      },
      internationalSchoolPrep: {
        name: 'International School Preparation',
        description:
          'Preparation support for students applying to international schools, tailored to each school\u2019s process.',
      },
      ielts: {
        name: 'IELTS',
        description:
          'Practice and guidance across listening, reading, writing, and speaking for the IELTS exam.',
      },
      toefl: {
        name: 'TOEFL',
        description: 'Preparation for the TOEFL exam, with a focus on academic English skills.',
      },
      sat: {
        name: 'SAT',
        description:
          'SAT preparation covering math, reading, and writing, tailored to the student\u2019s starting point.',
      },
    },
  },
  whyChoose: {
    eyebrow: 'Why APB',
    title: 'Why families choose APB.',
    description:
      'A small set of principles guides every lesson, every plan, and every conversation with parents.',
    features: {
      personalized: {
        title: 'Personalized Learning',
        description: 'Every plan starts with the student\u2019s current level, not a fixed syllabus pace.',
      },
      curriculumExpertise: {
        title: 'International Curriculum Support',
        description:
          'Academic support for students following IGCSE, A-Level, and IB programs, tailored to their school and subjects.',
      },
      educators: {
        title: 'Dedicated Educators',
        description:
          'Teachers who take the time to explain concepts clearly and check for real understanding.',
      },
      smallClasses: {
        title: 'Small-Group & Individual Learning',
        description: 'Individual or small-group sessions so every student gets real attention.',
      },
      progressTracking: {
        title: 'Progress-Focused Approach',
        description: 'Regular check-ins on strengths and gaps, so families always know where things stand.',
      },
      studentCentered: {
        title: 'Student-Centered Teaching',
        description: 'Lessons built around how each student learns best, not a one-size-fits-all method.',
      },
    },
  },
  journey: {
    eyebrow: 'The Process',
    title: 'A clear path from assessment to progress.',
    description:
      'Every student follows the same structured journey, calibrated to their own starting point and goals.',
    steps: {
      assessment: {
        title: 'Assessment',
        description: 'Understand the student\u2019s current level.',
      },
      plan: {
        title: 'Personalized Plan',
        description: 'Create a learning strategy based on the student\u2019s goals.',
      },
      learn: {
        title: 'Learn & Practice',
        description: 'Regular lessons with the student\u2019s teacher.',
      },
      achieve: {
        title: 'Progress',
        description: 'Track progress and work toward the student\u2019s academic goals.',
      },
    },
  },
  results: {
    eyebrow: 'What We Focus On',
    title: 'Progress That Matters',
    description:
      'APB does not publish invented scores or statistics. Here\u2019s what we actually focus on with every student.',
    footnote:
      'Specific scores, university placements, and statistics will be added here once available from APB.',
    benefits: {
      understanding: {
        title: 'Stronger Subject Understanding',
        description: 'Moving beyond memorization toward real understanding of core concepts.',
      },
      confidence: {
        title: 'Greater Academic Confidence',
        description:
          'Students who understand the material are more willing to engage and ask questions.',
      },
      habits: {
        title: 'Better Study Habits',
        description: 'Practical routines for reviewing, practicing, and preparing for assessments.',
      },
      goals: {
        title: 'Clearer Learning Goals',
        description: 'Each student works from a plan built around their own subjects and targets.',
      },
      tracking: {
        title: 'Consistent Progress Tracking',
        description: 'Regular check-ins so families always know how things are going.',
      },
    },
  },
  testimonials: {
    eyebrow: 'Testimonials',
    title: 'What parents say.',
    comingSoonTitle: 'Parent & Student Stories Coming Soon',
    comingSoonBody:
      'APB is currently collecting real feedback from families. Genuine testimonials from parents and students will appear here once they\u2019ve been shared with us.',
  },
  teachers: {
    eyebrow: 'Our Teachers',
    title: 'Meet the team.',
    description: 'Official APB teacher profiles are being finalized and will appear here soon.',
    cardTitle: 'Teacher Profile',
    cardStatus: 'Coming Soon',
    cardNote: 'Official name, subject, and qualifications to be added by APB.',
  },
  faq: {
    eyebrow: 'FAQ',
    title: 'Common questions.',
    description: 'Can\u2019t find what you\u2019re looking for? Reach out and the APB team will be happy to help.',
    items: [
      {
        question: 'What students does APB support?',
        answer:
          'APB works with primary through secondary school students, with support adapted to each student\u2019s year level and curriculum.',
      },
      {
        question: 'Do you support international school students?',
        answer: 'Yes. APB specializes in supporting students enrolled in international schools and international curricula.',
      },
      {
        question: 'What subjects do you teach?',
        answer:
          'APB offers support in English, Mathematics, and Science, along with IGCSE, A-Level, and IB coursework, and IELTS, TOEFL, and SAT preparation.',
      },
      {
        question: 'Do you provide IGCSE support?',
        answer: 'Yes, APB offers academic support for IGCSE across core and elective subjects.',
      },
      {
        question: 'Do you offer individual lessons?',
        answer: 'Yes. APB offers individual and small-group lessons depending on the student\u2019s needs and preferences.',
      },
      {
        question: 'Can students request a trial class?',
        answer: 'Yes, families can book a trial class to meet a teacher and see how APB\u2019s approach fits their child.',
      },
      {
        question: 'Where is APB located?',
        answer: 'APB is located at 111/29-30 Malada Maz, San Phak Wan, Hang Dong, Chiang Mai 50230, Thailand.',
      },
      {
        question: 'How can parents contact APB?',
        answer: 'You can call +66 61 272 9266 or fill out the booking form on this website and the APB team will follow up.',
      },
    ],
  },
  contact: {
    eyebrow: 'Get Started',
    title: 'Ready to Learn Beyond?',
    subtitle: 'Book a trial class or send a message \u2014 the APB team will get back to you shortly.',
    ctaPrimary: 'Book a Trial Class',
    ctaCall: 'Call APB',
    ctaDirections: 'Get Directions',
    visitTitle: 'Visit or contact us',
    locationLabel: 'Location',
    phoneLabel: 'Phone',
    directionsTitle: 'Get directions',
    directionsSubtitle: 'Open APB\u2019s location in Google Maps',
    formTitle: 'Request a trial class',
  },
  booking: {
    demoBannerTag: 'DEMO',
    demoBannerText:
      'This form is a frontend-only demo. Submissions aren\u2019t sent anywhere yet \u2014 a real booking endpoint needs to be connected before launch.',
    fields: {
      parentName: 'Parent Name',
      studentName: 'Student Name',
      ageOrYear: 'Age / Year Level',
      school: 'School',
      subject: 'Subject',
      program: 'Program',
      preferredDate: 'Preferred Date',
      preferredTime: 'Preferred Time',
      phone: 'Phone',
      email: 'Email',
      message: 'Message',
    },
    placeholders: {
      parentName: 'e.g. Somsak Suksri',
      studentName: 'e.g. Nina Suksri',
      ageOrYear: 'e.g. Year 9 / Age 14',
      school: 'Current school (optional)',
      subject: 'e.g. Mathematics',
      programSelect: 'Select a program',
      phone: '+66 6X XXX XXXX',
      email: 'you@example.com',
      message: 'Tell us a little about what your child needs support with.',
    },
    programOptions: {
      english: 'English',
      mathematics: 'Mathematics',
      science: 'Science',
      igcse: 'IGCSE',
      aLevel: 'A-Level',
      ib: 'IB',
      sat: 'SAT',
      ielts: 'IELTS',
      toefl: 'TOEFL',
      internationalSchoolPrep: 'International School Preparation',
      academicTutoring: 'Academic Tutoring',
    },
    errors: {
      parentName: 'Parent name is required.',
      studentName: 'Student name is required.',
      ageOrYear: 'Age or year level is required.',
      program: 'Please select a program.',
      phone: 'Phone number is required.',
      emailRequired: 'Email is required.',
      emailInvalid: 'Enter a valid email address.',
    },
    submit: 'Request a Trial Class',
    submitting: 'Sending request\u2026',
    successTitle: 'Request received',
    successBody:
      'Thank you, {name}. This is a demo confirmation \u2014 the form isn\u2019t connected to a live inbox yet. Once a backend is wired up, the APB team will follow up to confirm {student} trial class.',
    successBodyFallbackName: 'there',
    successBodyFallbackStudent: 'your child\u2019s',
    resetButton: 'Submit another request',
  },
  footer: {
    tagline: 'A Plus Beyond',
    rights: 'All rights reserved.',
    location: 'Hang Dong, Chiang Mai, Thailand',
  },
} as const

type Translations = typeof en

const zh: Translations = {
  meta: {
    htmlLang: 'zh-CN',
  },
  nav: {
    home: '首页',
    about: '关于我们',
    programs: '课程项目',
    whyApb: '为什么选择 APB',
    faq: '常见问题',
    contact: '联系我们',
    bookTrial: '预约试听课',
    languageToggleLabel: '切换为英文',
    languageToggleShort: 'EN',
  },
  hero: {
    badge: '清迈 \u00b7 国际教育',
    headlineLine1: '学有所成，',
    headlineEmphasis: '',
    headlineRest: '志存高远。',
    subtitle: '为清迈国际学校学生提供优质的学业支持。',
    ctaPrimary: '预约试听课',
    ctaSecondary: '浏览课程项目',
    trust: {
      curriculum: '国际课程体系',
      teachers: '用心教学',
      personalized: '个性化学习',
      location: '扎根清迈',
    },
    journey: {
      eyebrow: 'APB 学习成长路径',
      title: '学生的成长过程',
      stages: {
        assessment: '评估',
        plan: '个性化方案',
        learn: '学习与练习',
        progress: '进步',
      },
      footnote: '每位学生都遵循同样的路径',
      badgeLabel: '学习方案',
      badgeValue: '个性化定制',
    },
  },
  about: {
    eyebrow: '关于 APB',
    title: '专注国际教育的辅导中心。',
    description:
      'A Plus Beyond 的初衷很简单：帮助学习国际课程的学生真正理解学科内容，而不只是应付考试。',
    points: [
      '根据每位学生的节奏和目标制定个性化教学',
      '为学习国际课程的学生提供学业支持',
      '小班与一对一学习形式',
      '专注学科、一对一的关注',
      '以学生为中心的教学方式',
      '始终专注于帮助学生达成学习目标',
    ],
    paragraph:
      'APB 位于清迈汉东（Hang Dong），为学习国际课程的学生提供学业支持，包括 IGCSE、A-Level、IB 课程，以及 IELTS、TOEFL、SAT 备考，同时提供英语、数学、科学等核心学科辅导。课程内容可根据学生的学校、科目和学习目标进行调整。',
  },
  programs: {
    eyebrow: '课程项目',
    title: '覆盖国际学习各阶段的支持。',
    description: '从核心学科到国际课程与考试备考，每个项目都会根据学生的学校和目标进行调整。',
    footnote: '具体的学业支持将根据学生需求、科目及排课情况有所调整。',
    learnMore: '了解更多',
    categories: {
      academic: {
        title: '核心学科支持',
        subtitle: '围绕每位学生的学习节奏提供核心学科支持。',
      },
      internationalCurriculum: {
        title: '国际课程',
        subtitle: '为就读国际课程体系的学生提供学业支持。',
      },
      testPreparation: {
        title: '考试备考',
        subtitle: '针对主要英语及升学考试的系统化练习。',
      },
    },
    items: {
      english: {
        name: '英语',
        description: '阅读理解、写作与语言能力训练，根据学生所在学校和水平量身定制。',
      },
      mathematics: {
        name: '数学',
        description: '从基础技能到较高阶主题，以清晰的分步方式解题讲解。',
      },
      science: {
        name: '科学',
        description: '涵盖生物、化学、物理，帮助学生将课堂理论与实际理解结合。',
      },
      academicTutoring: {
        name: '学科辅导',
        description: '为需要持续、个性化关注的学生提供一般学科支持与作业指导。',
      },
      igcse: {
        name: 'IGCSE',
        description: '为学习 IGCSE 课程的学生提供学业支持，根据其科目和学校量身定制。',
      },
      aLevel: {
        name: 'A-Level',
        description: '针对 A-Level 学生的分科辅导，根据其课业和目标调整。',
      },
      ib: {
        name: 'IB',
        description: '为学习 IB 课程的学生提供学业支持，根据学生的科目和目标量身定制。',
      },
      internationalSchoolPrep: {
        name: '国际学校备考',
        description: '为申请国际学校的学生提供备考支持，根据各学校的申请流程量身定制。',
      },
      ielts: {
        name: 'IELTS 雅思',
        description: '针对雅思考试听力、阅读、写作、口语四个部分的练习与指导。',
      },
      toefl: {
        name: 'TOEFL 托福',
        description: '针对托福考试的备考辅导，注重学术英语能力的培养。',
      },
      sat: {
        name: 'SAT',
        description: '涵盖数学、阅读、写作的 SAT 备考，根据学生的起点水平量身定制。',
      },
    },
  },
  whyChoose: {
    eyebrow: '为什么选择 APB',
    title: '家长选择 APB 的理由。',
    description: '每一堂课、每一份学习方案、每一次与家长的沟通，都遵循同一套原则。',
    features: {
      personalized: {
        title: '个性化学习',
        description: '每份学习方案都从学生当前的水平出发，而非固定的教学进度。',
      },
      curriculumExpertise: {
        title: '国际课程支持',
        description: '为学习 IGCSE、A-Level、IB 课程的学生提供支持，根据学校与科目量身定制。',
      },
      educators: {
        title: '用心的老师',
        description: '老师会花时间把概念讲清楚，并确认学生是否真正理解。',
      },
      smallClasses: {
        title: '小班与一对一教学',
        description: '一对一或小班课程，确保每位学生都能获得真正的关注。',
      },
      progressTracking: {
        title: '注重学习进度',
        description: '定期检视学习强项与不足，让家长随时了解学习情况。',
      },
      studentCentered: {
        title: '以学生为中心的教学',
        description: '根据每位学生的学习方式设计课程，而非千篇一律的教学方法。',
      },
    },
  },
  journey: {
    eyebrow: '学习流程',
    title: '从评估到进步的清晰路径。',
    description: '每位学生都遵循同样的结构化学习流程，并根据自身起点和目标进行调整。',
    steps: {
      assessment: {
        title: '评估',
        description: '了解学生当前的学习水平。',
      },
      plan: {
        title: '个性化方案',
        description: '根据学生的目标制定学习策略。',
      },
      learn: {
        title: '学习与练习',
        description: '与老师进行定期课程学习。',
      },
      achieve: {
        title: '进步',
        description: '跟踪学习进度，朝着学生的学习目标努力。',
      },
    },
  },
  results: {
    eyebrow: '我们关注的重点',
    title: '真正重要的进步',
    description: 'APB 不会发布虚构的分数或统计数据。以下是我们真正关注、并与每位学生共同努力的方向。',
    footnote: '具体的分数、大学录取情况及统计数据，将在 APB 提供相关信息后补充。',
    benefits: {
      understanding: {
        title: '更扎实的学科理解',
        description: '从单纯记忆转向真正理解核心概念。',
      },
      confidence: {
        title: '更强的学习自信',
        description: '理解学习内容的学生，会更愿意参与课堂、主动提问。',
      },
      habits: {
        title: '更好的学习习惯',
        description: '建立实用的复习、练习及备考节奏。',
      },
      goals: {
        title: '更清晰的学习目标',
        description: '每位学生都拥有围绕自身科目和目标制定的学习方案。',
      },
      tracking: {
        title: '持续的学习进度跟踪',
        description: '定期检视学习情况，让家长随时了解进展。',
      },
    },
  },
  testimonials: {
    eyebrow: '家长评价',
    title: '家长怎么说。',
    comingSoonTitle: '家长与学生评价即将上线',
    comingSoonBody: 'APB 正在收集来自各个家庭的真实反馈。家长和学生的真实评价将在收集完成后展示于此。',
  },
  teachers: {
    eyebrow: '师资团队',
    title: '认识我们的老师。',
    description: 'APB 官方教师简介正在整理中，敬请期待。',
    cardTitle: '教师简介',
    cardStatus: '即将上线',
    cardNote: '教师姓名、任教科目及资历信息将由 APB 提供后补充。',
  },
  faq: {
    eyebrow: '常见问题',
    title: '常见问题解答。',
    description: '没有找到您想了解的问题？欢迎联系我们，APB 团队将乐意为您解答。',
    items: [
      {
        question: 'APB 支持哪些学生？',
        answer: 'APB 面向小学至中学阶段的学生，提供的支持会根据学生的年级和所学课程体系进行调整。',
      },
      {
        question: 'APB 是否支持国际学校的学生？',
        answer: '是的，APB 专注于为就读国际学校及学习国际课程体系的学生提供支持。',
      },
      {
        question: 'APB 教授哪些科目？',
        answer: 'APB 提供英语、数学、科学的学科支持，以及 IGCSE、A-Level、IB 课程辅导，还有 IELTS、TOEFL、SAT 备考。',
      },
      {
        question: 'APB 是否提供 IGCSE 支持？',
        answer: '是的，APB 提供针对 IGCSE 核心科目及选修科目的学业支持。',
      },
      {
        question: 'APB 是否提供一对一课程？',
        answer: '是的，APB 根据学生的需求和偏好，提供一对一或小班课程。',
      },
      {
        question: '学生可以预约试听课吗？',
        answer: '可以，家长可以预约试听课，让孩子与老师见面，感受 APB 的教学方式是否适合孩子。',
      },
      {
        question: 'APB 的地址在哪里？',
        answer: 'APB 位于泰国清迈汉东（Hang Dong）San Phak Wan，111/29-30 Malada Maz，邮编 50230。',
      },
      {
        question: '家长如何联系 APB？',
        answer: '您可以拨打 +66 61 272 9266，或填写网站上的预约表单，APB 团队将尽快与您联系。',
      },
    ],
  },
  contact: {
    eyebrow: '立即开始',
    title: '准备好开启学习之旅了吗？',
    subtitle: '预约试听课或留言给我们，APB 团队会尽快与您联系。',
    ctaPrimary: '预约试听课',
    ctaCall: '致电 APB',
    ctaDirections: '获取路线',
    visitTitle: '联系我们',
    locationLabel: '地址',
    phoneLabel: '电话',
    directionsTitle: '获取路线',
    directionsSubtitle: '在谷歌地图中查看 APB 的位置',
    formTitle: '预约试听课',
  },
  booking: {
    demoBannerTag: '演示版',
    demoBannerText: '此表单目前仅为前端演示，提交内容暂不会发送至任何系统 \u2014 正式上线前需接入真实的预约接口。',
    fields: {
      parentName: '家长姓名',
      studentName: '学生姓名',
      ageOrYear: '年龄 / 年级',
      school: '学校',
      subject: '科目',
      program: '课程项目',
      preferredDate: '期望日期',
      preferredTime: '期望时间',
      phone: '电话',
      email: '邮箱',
      message: '留言',
    },
    placeholders: {
      parentName: '例如：Somsak Suksri',
      studentName: '例如：Nina Suksri',
      ageOrYear: '例如：9 年级 / 14 岁',
      school: '目前就读学校（选填）',
      subject: '例如：数学',
      programSelect: '请选择课程项目',
      phone: '+66 6X XXX XXXX',
      email: 'you@example.com',
      message: '请简单描述孩子需要哪方面的学习支持。',
    },
    programOptions: {
      english: '英语',
      mathematics: '数学',
      science: '科学',
      igcse: 'IGCSE',
      aLevel: 'A-Level',
      ib: 'IB',
      sat: 'SAT',
      ielts: 'IELTS 雅思',
      toefl: 'TOEFL 托福',
      internationalSchoolPrep: '国际学校备考',
      academicTutoring: '学科辅导',
    },
    errors: {
      parentName: '请填写家长姓名。',
      studentName: '请填写学生姓名。',
      ageOrYear: '请填写年龄或年级。',
      program: '请选择课程项目。',
      phone: '请填写电话号码。',
      emailRequired: '请填写邮箱地址。',
      emailInvalid: '请输入有效的邮箱地址。',
    },
    submit: '提交试听申请',
    submitting: '正在提交\u2026',
    successTitle: '申请已收到',
    successBody:
      '感谢您，{name}。这只是演示确认 \u2014 表单尚未连接至真实收件系统。接入后端后，APB 团队将与您联系，确认{student}的试听课安排。',
    successBodyFallbackName: '您',
    successBodyFallbackStudent: '孩子',
    resetButton: '重新提交申请',
  },
  footer: {
    tagline: 'A Plus Beyond',
    rights: '版权所有。',
    location: '泰国清迈汉东（Hang Dong）',
  },
}

export const translations = { en, zh }
export type Language = keyof typeof translations
export type { Translations }
