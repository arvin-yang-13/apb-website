# A Plus Beyond (APB) — Website

A production-ready, bilingual (English / Simplified Chinese) marketing
site for A Plus Beyond, an international tutoring center in Chiang Mai,
Thailand. Built with React, TypeScript, Tailwind CSS, and Vite.

## 1. How to install

```bash
npm install
```

## 2. How to run locally

```bash
npm run dev
```

Then open the local URL Vite prints (usually `http://localhost:5173`).

## 3. How to build

```bash
npm run build
```

This runs a TypeScript project check (`tsc -b`) and then Vite's
production build, outputting static files to `dist/`. To preview the
production build locally:

```bash
npm run preview
```

To lint the project:

```bash
npm run lint
```

## 4. How to deploy to Vercel

This is a standard static Vite + React app — no custom server is
required.

**Option A — Vercel dashboard**
1. Push this project to a GitHub/GitLab/Bitbucket repo.
2. In Vercel, click **Add New → Project** and import the repo.
3. Vercel auto-detects the Vite framework preset:
   - Build command: `npm run build` (or `vite build`)
   - Output directory: `dist`
   - Install command: `npm install`
4. Click **Deploy**. No environment variables are required for the
   current frontend-only build.

**Option B — Vercel CLI**
```bash
npm install -g vercel
vercel        # first deploy, follow the prompts
vercel --prod # subsequent production deploys
```

No `vercel.json` is required for the current single-page layout (there
is no client-side router with multiple routes). If routing is added
later, add a rewrite so all paths fall back to `index.html`.

## 5. Where to change APB information

- **Address & phone**: appear in three places that must be kept in
  sync — `index.html` (JSON-LD structured data), and
  `src/components/Contact.tsx` (visible address text and `tel:` links).
  The phone number is currently `+66 61 272 9266`
  (`tel:+66612729266`).
- **All visible copy** (headlines, section text, FAQ, button labels,
  in both English and Chinese): `src/i18n/translations.ts`. See the
  "Bilingual" section below for how this file is organized.
- **Programs, Why-APB features, and journey steps** (icons and
  ordering only — text lives in `translations.ts`):
  `src/data/programs.ts`, `src/data/features.ts`, `src/data/journey.ts`.
- **Teacher slot count**: `src/data/teachers.ts`
  (`TEACHER_SLOT_COUNT`).

## 6. Where to connect the real booking form

`src/components/BookingForm.tsx` — the `handleSubmit` function has a
clearly marked block showing exactly where to replace the demo
`setTimeout` with a real request, e.g.:

```ts
const response = await fetch('https://your-api.example.com/bookings', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(values),
})
if (!response.ok) { setStatus('idle'); return /* show an error state */ }
```

Common options: a Vercel serverless function (`api/bookings.ts`), a
form service (Formspree, Getform), or a direct integration with APB's
CRM or inbox. The form also currently shows a visible "DEMO" banner
and its own translated disclaimer — remove both once a real endpoint
is connected.

## 7. Where to change the domain for SEO

Search and replace `https://www.aplusbeyond.example/` with the real
domain in:
- `index.html` — canonical link, Open Graph `og:url`, JSON-LD `url`
- `public/robots.txt` — the `Sitemap:` line
- `public/sitemap.xml` — the `<loc>` value

Also replace the placeholder `og:image` (currently the favicon) with a
real 1200×630 social-share image once one exists.

---

## Bilingual (English / 中文)

The whole site — nav, hero, every section, the booking form, and all
validation/success copy — is translated. A language toggle sits in the
navbar (desktop and mobile).

- All copy lives in **`src/i18n/translations.ts`**, in two objects, `en`
  and `zh`, that share one TypeScript shape (`zh` is typed against `en`,
  so the two can't drift out of structural sync — if you add a key to
  `en` and forget it in `zh`, TypeScript will fail to compile).
- **`src/i18n/LanguageContext.tsx`** provides the current language via
  React context, persists the choice to `localStorage`, defaults to the
  visitor's browser language on first visit, and updates
  `<html lang>` automatically.
- Any component that needs copy calls `const { t } = useLanguage()` and
  reads from `t.<section>.<key>`.
- Data files under `src/data/` intentionally hold **no text** — only
  ids, icons, and ordering. The ids are used to look up the matching
  copy in `translations.ts` for whichever language is active.
- Chinese text renders in system CJK fonts (PingFang SC / Microsoft
  YaHei) rather than a downloaded webfont, to keep the site fast.
- The physical address is intentionally left in its original
  Latin-script form in both languages (standard practice for Thai
  addresses, since local delivery/navigation depends on it).

To add a language, add a third object to `translations` in
`src/i18n/translations.ts` matching the `Translations` type, then add
it to the `Language` union and the toggle logic in
`LanguageContext.tsx`.

## Project structure

```
public/
  robots.txt           Allows indexing, points to sitemap.xml
  sitemap.xml           Single-page sitemap entry
  favicon.svg
src/
  components/        Page sections (Hero, Programs, Contact, etc.)
  components/ui/      Small shared UI pieces (cards, section headings)
  data/                Structure only: ids, icons, ordering — no copy
  i18n/                translations.ts (EN + ZH copy) and LanguageContext.tsx
  App.tsx              Assembles all sections
  index.css            Tailwind + design tokens + shared component classes
tailwind.config.js      Color palette, type scale, shadows, animation, fonts
```

## Content that still needs real APB information

This site was built with clearly-labeled placeholders wherever real data
wasn't provided, in both languages, per APB's request to never invent
teacher identities, qualifications, testimonials, or statistics. Before
launch, replace:

- **Teachers section** (`src/components/Teachers.tsx`,
  `src/data/teachers.ts`) — currently shows "Teacher Profile — Coming
  Soon" cards with no invented names, subjects, or qualifications.
- **Testimonials section** (`src/components/Testimonials.tsx`) —
  currently shows "Parent & Student Stories Coming Soon" instead of
  invented quotes.
- **Results section** (`src/components/Results.tsx`) — shows
  qualitative focus areas only ("Progress That Matters"), no invented
  statistics.
- **Booking form** — see "Where to connect the real booking form" above.
- **`index.html` / `robots.txt` / `sitemap.xml`** — see "Where to
  change the domain for SEO" above.

## Design notes

- Palette: navy/blue primary with a warm gold accent, on a soft ice-blue
  background. Glassmorphism, gradients, and glow effects are used
  sparingly and deliberately, not as a default treatment.
- Type: Fraunces (display/serif) paired with Inter (body) and IBM Plex
  Mono for small numeric/eyebrow labels, with system CJK font fallbacks
  for Chinese.
- Signature motif: a "ledger" of graduated tick marks used as a recurring
  divider — a quiet nod to grade reports and academic assessment. The
  hero's centerpiece visual, the "APB Learning Journey" card, follows
  the same idea without showing any invented student performance data.
- Every section with a nav anchor has `scroll-mt` set so the fixed
  navbar never overlaps section content when jumping via a nav link.
