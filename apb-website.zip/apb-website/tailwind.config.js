/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#0B1B33',
        navy: {
          DEFAULT: '#0F2A4A',
          50: '#EAF0F8',
          100: '#D3E0F0',
          200: '#A6C1E0',
          300: '#79A2D1',
          400: '#4C83C2',
          500: '#2A64A3',
          600: '#1E4FA3',
          700: '#163C7D',
          800: '#0F2A4A',
          900: '#081A30',
          950: '#050F1D',
        },
        ice: '#F4F8FC',
        gold: {
          DEFAULT: '#DE9F3C',
          50: '#FDF6EA',
          100: '#FAEACB',
          200: '#F3D392',
          300: '#ECBC5A',
          400: '#DE9F3C',
          500: '#C4832A',
          600: '#9C6720',
        },
      },
      fontFamily: {
        display: [
          '"Fraunces"',
          '"PingFang SC"',
          '"Microsoft YaHei"',
          'ui-serif',
          'Georgia',
          'serif',
        ],
        sans: [
          '"Inter"',
          '"PingFang SC"',
          '"Microsoft YaHei"',
          'ui-sans-serif',
          'system-ui',
          'sans-serif',
        ],
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'monospace'],
      },
      boxShadow: {
        soft: '0 8px 30px -8px rgba(15, 42, 74, 0.18)',
        card: '0 2px 8px -2px rgba(15, 42, 74, 0.08), 0 12px 32px -12px rgba(15, 42, 74, 0.14)',
        glow: '0 0 0 1px rgba(222, 159, 60, 0.25), 0 8px 24px -8px rgba(222, 159, 60, 0.35)',
      },
      backgroundImage: {
        'grid-lines':
          'linear-gradient(rgba(15,42,74,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(15,42,74,0.06) 1px, transparent 1px)',
      },
      animation: {
        'fade-up': 'fadeUp 0.7s cubic-bezier(0.16,1,0.3,1) both',
      },
      keyframes: {
        fadeUp: {
          '0%': { opacity: '0', transform: 'translateY(18px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
    },
  },
  plugins: [],
}
